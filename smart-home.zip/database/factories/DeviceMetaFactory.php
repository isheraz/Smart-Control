<?php

use Faker\Generator as Faker;

$factory->define(App\DeviceMeta::class, function (Faker $faker) {
    return [
        //
    ];
});
