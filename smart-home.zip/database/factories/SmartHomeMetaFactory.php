<?php

use Faker\Generator as Faker;

$factory->define(App\SmartHomeMeta::class, function (Faker $faker) {
    return [
        //
    ];
});
