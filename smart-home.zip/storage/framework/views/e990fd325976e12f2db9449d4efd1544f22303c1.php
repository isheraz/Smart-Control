<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">

                <div class="card">
                    <div class="card-header">
                        <h3>Device Serial: <?php echo e($device->serial); ?></h3>
                        <a href="<?php echo e(route('create-appliance', $device->id)); ?>" class="btn btn-success">Create New
                            Appliance</a>
                        <!-- Trigger the modal with a button -->
                        <button type="button" class="btn btn-info" data-toggle="modal"
                                data-target="#new-attribute">Create New Attribute</button>

                        <!-- Modal -->
                        <div id="new-attribute" class="modal fade" role="dialog">
                            <div class="modal-dialog">

                                <!-- Modal content-->
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <p class="mb-0 text-center">U can access these keys with the key name you define here</p>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('device-attribute')); ?>" method="post">
                                            <div class="form-group">
                                                <label for="key">Enter Key</label>
                                                <input type="text" name="key" id="key" class="form-control">
                                            </div>
                                           <?php echo csrf_field(); ?>
                                            <input type="hidden" name="device_id" value="<?php echo e($device->id); ?>">

                                            <div class="form-group">
                                                <label for="value">Enter Value</label>
                                                <input type="text" name="value" id="value" class="form-control">
                                            </div>
                                            <button type="submit" class="btn btn-outline-success">Save</button>

                                        </form>
                                    </div>
                                    <div class="modal-footer">
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>


                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-<?php echo e(session('alert-type')); ?> alert-dismissible">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <?php echo e(session('message')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="row">
                            <table class=" table-bordered table-stripped table">
                                <thead class="table-dark">
                                <tr>

                                    <?php $__currentLoopData = $device->device_metas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <th><?php echo e($meta->key); ?>

                                            <a href="<?php echo e(url('/meta/delete/'.$meta->id)); ?>" class="delete_node
                                            text-danger"
                                               style="font-size: 14px">
                                                <i class="fa fa-trash-o"></i>
                                            </a>
                                        </th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <?php $__currentLoopData = $device->device_metas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <td>
                                            <?php echo e($meta->value); ?><br>
                                            <small class="small">updated :<br> <?php echo e($meta->created_at->diffForHumans()); ?></small>
                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                                </tbody>
                            </table>
                        </div>

                        <form action="<?php echo e(route('update_node', $device->id)); ?>" method="post"
                              id="device_node">

                            <div class="row">


                                <?php $__currentLoopData = $device->nodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $node): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                        <section class="node border-dark mb-3 p-2 pt-3">

                                            <h5 class="pull-left pt-2">
                                                <i class="fa <?php echo e($node->icon); ?>"></i> <?php echo e($node->name); ?>

                                                <input type="hidden" id="node_icon" value="<?php echo e($node->icon); ?>">
                                            </h5>
                                            <div class="checkbox pull-right">
                                                <label>
                                                    <?php if($node->state): ?>

                                                        <input type="checkbox" data-toggle="toggle" checked
                                                               name="<?php echo e($node->name); ?>" class="node-state"
                                                               id="<?php echo e($node->id); ?>" value="<?php echo e($node->value); ?>">

                                                    <?php else: ?>
                                                        <input type="checkbox" data-toggle="toggle"
                                                               name="<?php echo e($node->name); ?>" class="node-state"
                                                               id="<?php echo e($node->id); ?>" value="<?php echo e($node->value); ?>">

                                                    <?php endif; ?>
                                                </label>
                                            </div>
                                            <a href="<?php echo e(route('delete_node', [$device->id, $node->id])); ?>"
                                               class="delete_node text-danger">
                                                <i class="fa fa-trash-o"></i>
                                            </a>
                                            <div class="clearfix"></div>

                                        </section>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </form>
                    </div>

                    <footer class="card-footer">
                        <small>
                            <?php if($device->connection): ?>
                                <i class="fa fa-globe text-success"></i>&nbsp;Connected
                            <?php else: ?>
                                <i class="fa fa-times text-dark-50"></i>&nbsp;Disconnected
                            <?php endif; ?>
                            :&nbsp;<?php echo e($device->updated_at->diffForHumans()); ?>

                        </small>
                    </footer>

                    <script>
                        //                        setTimeout(function () {
                        //                            window.location.reload();
                        //                        }, 10000);
                    </script>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>