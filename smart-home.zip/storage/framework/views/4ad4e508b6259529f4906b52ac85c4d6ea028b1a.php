<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <a class="btn btn-primary pull-right" href="<?php echo e(route('device_create')); ?>"><?php echo e(__('Create New Device')); ?></a>
                    </div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-<?php echo e(session('alert-type')); ?> alert-dismissible">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <?php echo e(session('message')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="row">
                            <section class="col-md-12">
                                <table class="table-bordered table-stripped table-light w-100">
                                    <thead>
                                    <tr class="text-center p-1">
                                        <th class="text-success">Connected</th>
                                        <th class="text-danger">Disconnected</th>
                                        <th class="text-info">Total</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td class="text-center"><h4><?php echo e($connected); ?></h4></td>
                                        <td class="text-center"><h4><?php echo e($disconnected); ?></h4></td>
                                        <td class="text-center"><h4><?php echo e(count($devices)); ?></h4></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </section>
                        </div>

                        <hr>
                        <div class="row">
                            <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3">
                                    <section class="sh-device" id="my-room">
                                        <a href="<?php echo e(route('configure',$device->id)); ?>" class="edit"><i class="fa
                                        fa-pencil"></i></a>
                                        <a href="<?php echo e(route('delete_device',$device->id)); ?>" class="text-danger delete"><i
                                                    class="fa
                                        fa-trash"></i></a>
                                        <?php if($device->connection): ?>
                                            <small class="text-success" title="connected"><i class="fa fa-globe"></i>
                                            </small>
                                            <p class="text-dark">
                                                <a href="<?php echo e(route('device', $device->id)); ?>" class="device-io">
                                                    <i class="fa <?php echo e($device->location_icon); ?>"></i>
                                                    <span><?php echo e($device->location_name); ?></span>
                                                </a>
                                            </p>
                                        <?php else: ?>
                                            <small class="text-black-50" title="disconnected"><i class="fa
                                                fa-times"></i></small>
                                            <p class="text-dark">
                                                <a href="<?php echo e(route('device', $device->id)); ?>" class="device-io">
                                                    <i class="fa <?php echo e($device->location_icon); ?>"></i>
                                                    <span><?php echo e($device->location_name); ?></span>
                                                </a>
                                            </p>
                                        <?php endif; ?>

                                        <span class="text-dark-50 device-serial"><?php echo e($device->serial); ?></span>
                                        <span class="text-dark-50 device-history"><a
                                                    href="<?php echo e(route('history', $device->id)); ?>">History</a></span>
                                    </section>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>